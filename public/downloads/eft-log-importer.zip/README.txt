Kappa Progress Tracker - EFT Log Importer
================================================

Este paquete genera kappa-progress-import.json leyendo logs locales de Escape from Tarkov.

Privacidad
----------
- Solo lee EscapeFromTarkov/Logs/**/push-notifications_*.log.
- No modifica archivos del juego.
- No pide credenciales.
- No hace llamadas de red.

Uso Recomendado
---------------
1. Cierra Escape from Tarkov y Battlestate Launcher.
2. Descomprime este ZIP en una carpeta normal, por ejemplo Descargas.
3. Ejecuta el script de tu sistema:
   - Windows: doble click en run-windows.bat
   - Linux/macOS/WSL: ./run-linux.sh
4. Cuando pregunte por la carpeta de instalacion, introduce la carpeta EscapeFromTarkov que contiene Logs.
5. Cuando pregunte por salida, pulsa Enter para usar kappa-progress-import.json.
6. Vuelve a la web, abre /import y sube el JSON generado.

Ejemplos De Ruta
----------------
Windows:
C:\Games\EscapeFromTarkov
C:\Battlestate Games\EFT\EscapeFromTarkov

WSL:
/mnt/c/Users/<usuario>/Desktop/EFTINSTALLFOLDER/EscapeFromTarkov

Solucion De Problemas
---------------------
- Si Node.js no esta instalado, los scripts intentan instalarlo o muestran instrucciones.
- Si el extractor dice que no encuentra Logs, revisa que la ruta sea la carpeta EscapeFromTarkov, no la carpeta Logs.
- Si detecta 0 completadas, puede que los logs antiguos hayan rotado o no contengan eventos successMessageText.
- El JSON no es una foto completa del perfil: solo contiene eventos que siguen presentes en tus logs locales.
