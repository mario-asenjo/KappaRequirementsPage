#!/usr/bin/env sh
set -eu

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js no esta instalado. Intentando instalarlo..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y nodejs
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y nodejs
  elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -S --needed nodejs
  elif command -v brew >/dev/null 2>&1; then
    brew install node
  else
    echo "No pude instalar Node automaticamente. Instala Node.js LTS desde https://nodejs.org/"
    exit 1
  fi
fi

printf "Carpeta EscapeFromTarkov (Enter para autodetectar): "
read -r EFT_PATH_INPUT
printf "Archivo de salida [kappa-progress-import.json]: "
read -r OUT_PATH
OUT_PATH="${OUT_PATH:-kappa-progress-import.json}"

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -z "$EFT_PATH_INPUT" ]; then
  node "$SCRIPT_DIR/eft-log-importer.mjs" --out "$OUT_PATH"
else
  node "$SCRIPT_DIR/eft-log-importer.mjs" --eft "$EFT_PATH_INPUT" --out "$OUT_PATH"
fi

echo "Si se genero correctamente, importa $OUT_PATH en la pagina /import."
