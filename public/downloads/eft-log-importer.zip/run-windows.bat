@echo off
setlocal
title Kappa Progress Tracker - EFT Log Importer

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
  echo Node.js no esta instalado.
  where winget >nul 2>nul
  if %ERRORLEVEL% equ 0 (
    echo Intentando instalar Node.js LTS con winget...
    winget install OpenJS.NodeJS.LTS
  ) else (
    echo Instala Node.js LTS desde https://nodejs.org/ y vuelve a ejecutar este archivo.
    start https://nodejs.org/
    pause
    exit /b 1
  )
)

echo.
echo Carpeta de instalacion de EscapeFromTarkov.
echo Dejala vacia para intentar autodeteccion.
set /p EFT_PATH_INPUT=Ruta EFT: 

echo.
set /p OUT_PATH=Archivo de salida [kappa-progress-import.json]: 
if "%OUT_PATH%"=="" set OUT_PATH=kappa-progress-import.json

if "%EFT_PATH_INPUT%"=="" (
  node "%~dp0eft-log-importer.mjs" --out "%OUT_PATH%"
) else (
  node "%~dp0eft-log-importer.mjs" --eft "%EFT_PATH_INPUT%" --out "%OUT_PATH%"
)

echo.
echo Si se genero correctamente, importa %OUT_PATH% en la pagina /import.
pause
